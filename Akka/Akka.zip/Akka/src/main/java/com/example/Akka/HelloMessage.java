package com.example.Akka;

public class HelloMessage {
}
